#!/bin/sh

# Log everything this script does (and any errors) to a file we can inspect
# after login, since this runs with no visible terminal attached.
mkdir -p "$HOME/.local/share/qtile"
exec >> "$HOME/.local/share/qtile/autostart.log" 2>&1
echo "---- autostart.sh run at $(date) ----"
set -x  # print each command as it runs, into the log above

# Fix oversized root-window cursor -- see ~/.Xresources for details.
xrdb -merge ~/.Xresources
export XCURSOR_SIZE=24
xsetroot -cursor_name left_ptr

# Apply saved monitor profile (matches by EDID, survives output renaming/hotplug).
# Set this up once with:
#   xrandr --output DP-1 --mode 1920x1080 --rate 165 --pos 0x0 --rotate normal --primary \
#          --output DP-2 --mode 1920x1080 --rate 144 --rotate right --pos 1920x0 \
#          --output DP-3 --mode 1920x1080 --rate 144 --rotate normal --pos 3000x0 \
#          --output HDMI-A-1 --mode 1920x1080 --rate 60 --rotate normal --same-as DP-1
#   autorandr --save quad-mirror
autorandr --change --default quad-mirror

# Fallback if autorandr / profile isn't set up yet -- uncomment to use raw xrandr instead:
# xrandr \
#   --output DP-1 --mode 1920x1080 --rate 165 --pos 0x0 --rotate normal --primary \
#   --output DP-2 --mode 1920x1080 --rate 144 --rotate right --pos 1920x0 \
#   --output DP-3 --mode 1920x1080 --rate 144 --rotate normal --pos 3000x0 \
#   --output HDMI-A-1 --mode 1920x1080 --rate 60 --rotate normal --same-as DP-1

# Give the X server a beat to finish applying the monitor layout above
# before anything queries output geometry (avoids races on some drivers).
sleep 1

# Wallpaper: xwallpaper reads geometry straight from RandR per output
# (including any transform/rotation applied), unlike feh/nitrogen which
# can miscompute fill dimensions on a rotated output and only cover half
# the screen.
#
# --zoom crops-to-fill while preserving aspect ratio (no distortion).
# --stretch was used before, which forces the image into the exact box --
# on DP-2's rotated 1080x1920 portrait box, that warped a landscape image.
WALLPAPER="$HOME/Pictures/wallpaper.jpg"

# Optional: if you have a portrait-oriented image, use it for DP-2 instead --
# --zoom on a landscape image in a portrait box will only show a narrow,
# heavily-zoomed vertical slice of the middle of the image. A real portrait
# crop looks much better here. Point this at one if you have it; otherwise
# it just falls back to the same image as the others.
WALLPAPER_PORTRAIT="$HOME/Pictures/wallpaper-portrait.jpg"
if [ ! -f "$WALLPAPER_PORTRAIT" ]; then
  WALLPAPER_PORTRAIT="$WALLPAPER"
fi

xwallpaper \
  --output DP-1 --zoom "$WALLPAPER" \
  --output DP-2 --zoom "$WALLPAPER_PORTRAIT" \
  --output DP-3 --zoom "$WALLPAPER"

# Note: HDMI-A-1 needs no entry -- it's cloning DP-1 via --same-as, so
# whatever xwallpaper draws on DP-1 shows up there automatically too.
# If you'd rather crop-to-fill instead of stretch, use --zoom in place
# of --stretch above.

# Compositor -- gives us rounded window corners (see ~/.config/picom/picom.conf).
# pkill first so reloading autostart (or a qtile restart) doesn't stack up
# duplicate picom processes fighting over compositing.
pkill picom
picom --config ~/.config/picom/picom.conf &
