#!/bin/sh
# Power menu -- shown via rofi, triggered by clicking the power icon in the bar.

options="Log Out\nLock\nRestart\nShut Down"

chosen=$(printf "%b" "$options" | rofi -dmenu -p "Power" -theme ~/.config/rofi/theme.rasi)

case "$chosen" in
    "Log Out")
        qtile cmd-obj -o cmd -f shutdown
        ;;
    "Lock")
        # Requires a lock screen tool to actually be installed --
        # betterlockscreen (built on i3lock) is what we discussed earlier.
        # If you haven't set that up yet, swap this for whatever you use,
        # e.g. plain `i3lock`.
        betterlockscreen -l
        ;;
    "Restart")
        systemctl reboot
        ;;
    "Shut Down")
        systemctl poweroff
        ;;
    *)
        # No option chosen (Escape pressed, etc.) -- do nothing
        ;;
esac
