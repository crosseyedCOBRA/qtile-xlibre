#!/bin/sh
# Usage: toggle-picom.sh [on|off]
# With no argument, toggles based on whether picom is currently running.

case "$1" in
  off)
    pkill picom
    ;;
  on)
    pkill picom
    picom --config ~/.config/picom/picom.conf &
    ;;
  *)
    if pgrep -x picom > /dev/null; then
      pkill picom
    else
      picom --config ~/.config/picom/picom.conf &
    fi
    ;;
esac
