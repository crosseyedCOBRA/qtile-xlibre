import os
import subprocess

from libqtile import bar, layout, qtile, widget, hook
from libqtile.config import Click, Drag, Group, Key, Match, Screen
from libqtile.lazy import lazy

mod = "mod4"  # Super key
terminal = "kitty"


def _move_window_to_next_screen(qtile, direction):
    """Move the focused window to the next/previous monitor and keep it
    tiled there (rather than qtile's mouse-drag default, which floats a
    window the moment you start dragging it)."""
    window = qtile.current_window
    if window is None:
        return
    screens = qtile.screens
    current_index = qtile.screens.index(qtile.current_screen)
    target_index = (current_index + direction) % len(screens)
    target_group = screens[target_index].group.name
    window.togroup(target_group, switch_group=False)
    qtile.groups_map[target_group].cmd_toscreen(target_index)


def _move_or_swap_window(qtile, direction):
    """Move/swap the focused window in the given direction, working
    correctly across different layout types:

    - MonadTall (and similar shuffle-based layouts): uses the layout's own
      shuffle_<direction>() command.
    - Matrix: MonadTall-style shuffle_* commands don't exist on Matrix, but
      it does have a lower-level swap(window1, window2) method (confirmed
      by inspecting the actual libqtile.layout.Matrix source -- it's not
      exposed as a simple directional command by default). This moves
      focus to the neighboring cell via Matrix's own up/down/left/right
      navigation, then swaps the two windows' positions, then restores
      focus onto the originally-selected window in its new spot.
    """
    group = qtile.current_group
    current_layout = group.layout
    layout_name = getattr(current_layout, "name", "")

    if layout_name == "matrix":
        current_window = qtile.current_window
        if current_window is None:
            return
        nav = getattr(current_layout, direction, None)
        if nav is None:
            return
        nav()  # shifts focus to the neighboring cell in that direction
        other_window = qtile.current_window
        if other_window and other_window is not current_window:
            current_layout.swap(current_window, other_window)
            group.focus(current_window)
    else:
        shuffle = getattr(current_layout, f"shuffle_{direction}", None)
        if shuffle:
            shuffle()

# ---------------------------------------------------------------------------
# Autostart: apply monitor layout before anything else draws
# ---------------------------------------------------------------------------
@hook.subscribe.startup_once
def autostart():
    autostart_script = os.path.expanduser("~/.config/qtile/autostart.sh")
    subprocess.call([autostart_script])


# ---------------------------------------------------------------------------
# Keybindings
# ---------------------------------------------------------------------------
keys = [
    # Window focus movement
    Key([mod], "h", lazy.layout.left(), desc="Move focus left"),
    Key([mod], "l", lazy.layout.right(), desc="Move focus right"),
    Key([mod], "j", lazy.layout.down(), desc="Move focus down"),
    Key([mod], "k", lazy.layout.up(), desc="Move focus up"),
    Key([mod], "space", lazy.spawn("rofi -show drun -m -5 -theme ~/.config/rofi/theme.rasi"), desc="Launch rofi (on cursor's monitor)"),

    # Move windows within layout
    Key([mod, "shift"], "h", lazy.function(_move_or_swap_window, "left"), desc="Move/swap window left"),
    Key([mod, "shift"], "l", lazy.function(_move_or_swap_window, "right"), desc="Move/swap window right"),
    Key([mod, "shift"], "j", lazy.function(_move_or_swap_window, "down"), desc="Move/swap window down"),
    Key([mod, "shift"], "k", lazy.function(_move_or_swap_window, "up"), desc="Move/swap window up"),

    # Resize windows
    Key([mod, "control"], "h", lazy.layout.grow_left(), desc="Grow window left"),
    Key([mod, "control"], "l", lazy.layout.grow_right(), desc="Grow window right"),
    Key([mod, "control"], "j", lazy.layout.grow_down(), desc="Grow window down"),
    Key([mod, "control"], "k", lazy.layout.grow_up(), desc="Grow window up"),
    Key([mod], "n", lazy.layout.normalize(), desc="Reset window sizes"),

    # Layout / window management
    Key([mod, "shift"], "Return", lazy.layout.toggle_split(), desc="Toggle split stack"),
    Key([mod], "Return", lazy.spawn(terminal), desc="Launch terminal"),
    Key([mod], "e", lazy.spawn("thunar"), desc="Launch Thunar file manager"),
    Key([mod], "Tab", lazy.next_layout(), desc="Cycle layouts"),
    Key([mod], "g", lazy.group.setlayout("matrix"),
        desc="Switch current monitor's layout to Matrix (2x2 with 4 windows)"),
    Key([mod], "t", lazy.group.setlayout("monadtall"),
        desc="Switch current monitor's layout back to MonadTall"),
    Key([mod], "q", lazy.window.kill(), desc="Kill focused window"),
    Key([mod, "control"], "p", lazy.spawn(os.path.expanduser("~/.config/qtile/toggle-picom.sh")),
        desc="Toggle picom compositor (off before gaming for lower latency)"),
    Key([], "Print", lazy.spawn(os.path.expanduser("~/.config/qtile/screenshot.sh")),
        desc="Screenshot: select a region"),
    Key(["shift"], "Print", lazy.spawn([os.path.expanduser("~/.config/qtile/screenshot.sh"), "full"]),
        desc="Screenshot: full screen"),
    Key([mod, "shift"], "space", lazy.window.toggle_floating(), desc="Toggle floating"),
    Key([mod, "control"], "r", lazy.reload_config(), desc="Reload config"),
    Key([mod, "control"], "q", lazy.shutdown(), desc="Shutdown qtile"),
    Key([mod], "r", lazy.spawncmd(), desc="Spawn a command"),

    # Move focus between screens (monitors)
    Key([mod], "period", lazy.next_screen(), desc="Move focus to next monitor"),
    Key([mod], "comma", lazy.prev_screen(), desc="Move focus to previous monitor"),

    # Move the focused WINDOW to the next/previous monitor, staying tiled --
    # this is the keyboard equivalent of "drag it to another screen and have
    # it tile there", since qtile's mouse drag always floats a window instead.
    Key([mod, "shift"], "period", lazy.function(_move_window_to_next_screen, 1),
        desc="Move focused window to next monitor (stays tiled)"),
    Key([mod, "shift"], "comma", lazy.function(_move_window_to_next_screen, -1),
        desc="Move focused window to previous monitor (stays tiled)"),
]

# ---------------------------------------------------------------------------
# Groups (workspaces) pinned to specific monitors:
#   1, 4, 5 -> DP-1 (screen 0)
#   2       -> DP-2 (screen 1)
#   3       -> DP-3 (screen 2)
#
# Rather than qtile's default lazy.group[x].toscreen() (which just puts a
# group on whatever screen currently has focus), these bindings always send
# the group to its assigned screen index -- so "2" always lands on DP-2 no
# matter which monitor you pressed the key from. That's what makes the
# pinning stick instead of drifting the first time you switch groups from
# the "wrong" screen.
# ---------------------------------------------------------------------------
group_screen_map = {
    "1": 0,
    "2": 1,
    "3": 2,
    "4": 0,
    "5": 0,
}

groups = [Group(name) for name in group_screen_map]


def _go_to_group(qtile, name, screen_index):
    qtile.groups_map[name].cmd_toscreen(screen_index)


def _move_window_to_group(qtile, name, screen_index):
    window = qtile.current_window
    if window is None:
        return
    window.togroup(name, switch_group=False)
    qtile.groups_map[name].cmd_toscreen(screen_index)


for name, screen_index in group_screen_map.items():
    keys.extend([
        Key([mod], name, lazy.function(_go_to_group, name, screen_index),
            desc=f"Show group {name} on its assigned monitor"),
        Key([mod, "shift"], name, lazy.function(_move_window_to_group, name, screen_index),
            desc=f"Move focused window to group {name} (auto-tiles there)"),
    ])


@hook.subscribe.startup_complete
def pin_groups_on_login():
    """Put 2 and 3 on their monitors right away, rather than waiting for the
    first time you press mod+2 / mod+3. Group 1 is qtile's default on
    screen 0 already, so it needs no explicit push here."""
    qtile.groups_map["2"].cmd_toscreen(1)
    qtile.groups_map["3"].cmd_toscreen(2)

# ---------------------------------------------------------------------------
# Layouts
# ---------------------------------------------------------------------------
layout_theme = {
    "border_width": 2,
    "margin": 6,
    "border_focus": "8be9fd",
    "border_normal": "44475a",
}

layouts = [
    layout.MonadTall(**layout_theme),
    layout.Matrix(columns=2, **layout_theme),
]

# ---------------------------------------------------------------------------
# Widgets / bar
# ---------------------------------------------------------------------------
# Colors pulled directly from the cosmic wallpaper (extracted from its actual
# dominant palette, not guessed): deep space navy, indigo cloud, teal moon-glow,
# nebula purple, and dusty coral-pink from the planet.
colors = {
    "bg": "#0c0b1a",          # bar background -- matches the wallpaper's black sky
    "pill": "#1b204c",        # indigo -- matches the wallpaper's cloud/nebula base
    "pill_active": "#2d3a74", # slightly brighter indigo, for the active workspace
    "text": "#e8e6f0",        # soft lavender-white
    "text_muted": "#8890b5",
    "teal": "#4da4a6",        # moon glow
    "blue": "#5b7fd6",        # brightened from the wallpaper's deep blue for readability
    "purple": "#b882be",      # nebula purple
    "coral": "#c55a63",       # planet pink/coral
}

widget_defaults = dict(
    font="JetBrainsMono Nerd Font SemiBold",
    fontsize=13,
    padding=6,
    foreground=colors["text"],
)
extension_defaults = widget_defaults.copy()


def make_bar(show_systray=False):
    """Return a fresh Bar instance -- each Screen needs its own widget objects,
    so this is called once per screen rather than sharing one bar.

    Only ONE screen should ever pass show_systray=True: the X systray
    protocol only allows a single owner of the tray selection, and qtile
    will raise ConfigError("Only one Systray can be used.") -- crashing the
    whole bar config -- if more than one Systray() widget is instantiated.
    """
    left = [
        # openSUSE geeko launcher -- click to open rofi (same action as Super+Space)
        widget.Image(
            filename="~/.config/qtile/icons/opensuse-logo.png",
            margin=6,
            mouse_callbacks={"Button1": lazy.spawn("rofi -show drun -m -5 -theme ~/.config/rofi/theme.rasi")},
        ),
        widget.GroupBox(
            active=colors["text"],
            inactive=colors["text_muted"],
            highlight_method="block",
            block_highlight_text_color=colors["bg"],
            this_current_screen_border=colors["teal"],
            this_screen_border=colors["teal"],
            other_current_screen_border=colors["pill_active"],
            other_screen_border=colors["pill_active"],
            urgent_border=colors["coral"],
            rounded=False,
            margin_x=2,
            padding_x=4,
        ),
    ]

    center = [
        widget.Clock(
            format="%A %B %d %Y %H%M",
            foreground=colors["text"],
        ),
    ]

    right = []

    if show_systray:
        right.append(widget.Systray())

    right.extend([
        widget.CPU(
            format="\uf2db {load_percent}%",
            foreground=colors["coral"],
        ),
        widget.ThermalSensor(
            format="\uf2c7 {temp:.0f}{unit}",
            tag_sensor="Tctl",  # k10temp CPU die sensor -- verify with the
                                 # psutil command above and adjust if different
            foreground=colors["blue"],
        ),
        widget.ThermalSensor(
            format="\uf2c7 {temp:.0f}{unit}",
            tag_sensor="edge",  # amdgpu GPU sensor -- verify with the
                                 # psutil command above and adjust if different
            foreground=colors["teal"],  # kept the weather widget's old color
        ),
        widget.Volume(
            fmt="\uf028 {}",
            foreground=colors["purple"],
            mouse_callbacks={
                "Button1": lazy.spawn("pavucontrol"),
                "Button3": lazy.spawn("pactl set-sink-mute @DEFAULT_SINK@ toggle"),
            },
        ),
        widget.TextBox(
            text="\uf030",
            fontsize=16,
            foreground=colors["blue"],
            mouse_callbacks={
                "Button1": lazy.spawn(os.path.expanduser("~/.config/qtile/screenshot.sh")),
                "Button3": lazy.spawn([os.path.expanduser("~/.config/qtile/screenshot.sh"), "full"]),
            },
        ),
        widget.TextBox(
            text="\uf011",
            fontsize=16,
            foreground=colors["coral"],
            mouse_callbacks={"Button1": lazy.spawn(os.path.expanduser("~/.config/qtile/powermenu.sh"))},
        ),
    ])

    widgets = (
        left
        + [widget.Spacer(length=bar.STRETCH)]
        + center
        + [widget.Spacer(length=bar.STRETCH)]
        + right
    )
    return bar.Bar(widgets, 36, background=colors["bg"] + "bf", margin=[4, 8, 6, 8])



# ---------------------------------------------------------------------------
# Screens -- one per active output as arranged by xrandr (DP-1, DP-2, DP-3).
# HDMI-A-1 mirrors DP-1 at the X server level, so it doesn't need its own
# Screen entry here -- it will simply display whatever's on Screen 0.
# Systray only goes on the first screen -- see make_bar() docstring.
# ---------------------------------------------------------------------------
screens = [
    Screen(top=make_bar(show_systray=True)),  # DP-1
    Screen(top=make_bar()),                   # DP-2 (rotated)
    Screen(top=make_bar()),                   # DP-3
]

# ---------------------------------------------------------------------------
# Mouse
# ---------------------------------------------------------------------------
mouse = [
    Drag([mod], "Button1", lazy.window.set_position_floating(), start=lazy.window.get_position()),
    Drag([mod], "Button3", lazy.window.set_size_floating(), start=lazy.window.get_size()),
    Click([mod], "Button2", lazy.window.bring_to_front()),
]

dgroups_key_binder = None
dgroups_app_rules = []
follow_mouse_focus = True
bring_front_click = False
cursor_warp = False

floating_layout = layout.Floating(
    float_rules=[
        *layout.Floating.default_float_rules,
        Match(wm_class="confirmreset"),
        Match(wm_class="makebranch"),
        Match(wm_class="maketag"),
        Match(title="branchdialog"),
        Match(title="pinentry"),
    ]
)

auto_fullscreen = True
focus_on_window_activation = "smart"
reconfigure_screens = True
auto_minimize = True
wmname = "LG3D"
